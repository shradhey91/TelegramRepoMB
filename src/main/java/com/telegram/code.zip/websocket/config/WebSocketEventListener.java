package com.telegram.websocket.config;

import com.telegram.user.repository.UserRepo;
import com.telegram.auth.security.CustomUserDetails;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Map;

@Component
public class WebSocketEventListener {

    private final UserRepo userRepo;
    private final SimpMessagingTemplate messagingTemplate;

    public WebSocketEventListener(UserRepo userRepo, SimpMessagingTemplate messagingTemplate) {
        this.userRepo = userRepo;
        this.messagingTemplate = messagingTemplate;
    }

    @EventListener
    public void handleWebSocketConnect(SessionConnectEvent event) {
        var principal = event.getUser();
        if (principal == null) return;

        Long userId = extractUserId(principal);
        if (userId == null) return;

        userRepo.findById(userId).ifPresent(user -> {
            user.setIsOnline(true);
            userRepo.save(user);

            messagingTemplate.convertAndSend("/topic/presence",
                    (Object) Map.of("userId", userId, "isOnline", true));
        });
    }

    @EventListener
    public void handleWebSocketDisconnect(SessionDisconnectEvent event) {
        var principal = event.getUser();
        if (principal == null) return;

        Long userId = extractUserId(principal);
        if (userId == null) return;

        userRepo.findById(userId).ifPresent(user -> {
            user.setIsOnline(false);
            user.setLastSeenAt(OffsetDateTime.now(ZoneOffset.UTC));
            userRepo.save(user);

            messagingTemplate.convertAndSend("/topic/presence",
                    (Object) Map.of("userId", userId,
                            "isOnline", false,
                            "lastSeenAt", OffsetDateTime.now(ZoneOffset.UTC).toString()));
        });
    }

    private Long extractUserId(java.security.Principal principal) {
        if (principal instanceof UsernamePasswordAuthenticationToken auth) {
            if (auth.getPrincipal() instanceof CustomUserDetails userDetails) {
                return userDetails.getId();
            }
        }
        return null;
    }
}